#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <errno.h>

int main() {
    int fd;
    struct winsize w;

    // Open terminal device
    fd = open("/dev/tty", O_RDWR);
    if (fd < 0) {
        perror("open /dev/tty failed");
        return 1;
    }

    printf("[+] /dev/tty opened successfully (fd=%d)\n", fd);

    /* -----------------------------------------------------
       1. GET TERMINAL SIZE USING ioctl (TIOCGWINSZ)
       ----------------------------------------------------- */
    if (ioctl(fd, TIOCGWINSZ, &w) == -1) {
        perror("ioctl TIOCGWINSZ failed");
        close(fd);
        return 1;
    }

    printf("[+] Current terminal size:\n");
    printf("    Rows:    %d\n", w.ws_row);
    printf("    Columns: %d\n", w.ws_col);
    printf("    Xpixels: %d\n", w.ws_xpixel);
    printf("    Ypixels: %d\n", w.ws_ypixel);

    /* -----------------------------------------------------
       2. SET TERMINAL SIZE USING ioctl (TIOCSWINSZ)
          (Requires root privileges)
       ----------------------------------------------------- */
    printf("\n[*] Setting terminal size to 40x100 (requires root)...\n");

    w.ws_row = 40;
    w.ws_col = 100;

    if (ioctl(fd, TIOCSWINSZ, &w) == -1) {
        perror("ioctl TIOCSWINSZ failed (expected if not root)");
    } else {
        printf("[+] Terminal size changed successfully.\n");
    }

    close(fd);
    return 0;
}

