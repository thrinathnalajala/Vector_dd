// SPDX-License-Identifier: GPL-2.0
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <linux/watchdog.h>
#include <sys/ioctl.h>

int fd;

void sigint_handler(int sig) {
    if (fd > 0)
        close(fd);  // disarm watchdog safely
    printf("\nExiting, watchdog disarmed\n");
    exit(0);
}

int main(void)
{
    signal(SIGINT, sigint_handler);

    fd = open("/dev/watchdog", O_WRONLY);
    if (fd == -1) {
        perror("watchdog");
        exit(EXIT_FAILURE);
    }

    int timeout = 30; // seconds
    ioctl(fd, WDIOC_SETTIMEOUT, &timeout);
    printf("Watchdog timeout set to %d seconds\n", timeout);

    while (1) {
        int ret = write(fd, "\0", 1);
        if (ret != 1) {
            perror("write to /dev/watchdog");
            break;
        }
        sleep(10); // feed every 10 seconds
    }

    close(fd);
    return 0;
}

