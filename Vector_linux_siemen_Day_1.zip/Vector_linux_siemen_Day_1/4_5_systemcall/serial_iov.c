#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <errno.h>
#include <termios.h>

int main() {
    int fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY);
    if (fd < 0) {
        perror("open /dev/ttyUSB0");
        return 1;
    }

    // Configure serial port (115200 8N1, raw)
    struct termios options;
    tcgetattr(fd, &options);
    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_lflag &= ~(ICANON | ECHO | ISIG);
    options.c_oflag &= ~OPOST;
    tcsetattr(fd, TCSANOW, &options);

    // Scatter read: separate buffers for header, payload, checksum
    char header[2], payload[10], checksum[1];
    struct iovec iov[3];
    iov[0].iov_base = header;
    iov[0].iov_len  = sizeof(header);
    iov[1].iov_base = payload;
    iov[1].iov_len  = sizeof(payload);
    iov[2].iov_base = checksum;
    iov[2].iov_len  = sizeof(checksum);

    ssize_t n = readv(fd, iov, 3);
    if (n < 0) {
        perror("readv");
        close(fd);
        return 1;
    }

    printf("Received %zd bytes:\n", n);
    printf("Header: %.*s\n", (int)sizeof(header), header);
    printf("Payload: %.*s\n", (int)sizeof(payload), payload);
    printf("Checksum: %.*s\n", (int)sizeof(checksum), checksum);

    // Gather write: respond with ACK message
    char ack1[] = "ACK-";
    char *ack2 = header;   // include header in response
    char ack3[] = "\n";

    struct iovec out_iov[3];
    out_iov[0].iov_base = ack1;
    out_iov[0].iov_len  = strlen(ack1);
    out_iov[1].iov_base = ack2;
    out_iov[1].iov_len  = sizeof(header);
    out_iov[2].iov_base = ack3;
    out_iov[2].iov_len  = strlen(ack3);

    ssize_t nw = writev(fd, out_iov, 3);
    if (nw < 0) {
        perror("writev");
        close(fd);
        return 1;
    }

    printf("Sent %zd bytes as ACK\n", nw);

    close(fd);
    return 0;
}

