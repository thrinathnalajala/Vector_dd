int mystrlen(char*);
void mystrcpy(char*);
int mystrcmp();
void mystrrev();
#ifdef MAIN
#define global extern
#else
#define global 
#endif
