int main()
{
  printf("happy");
  while(1)
  {
    printf("days");
  }
  printf("tree");
}

