  /* A sample program */
  int main() {
    int i = 0;
     if (i == 0)
        i = 1;
   return 0;
 }

