// shared_defs.h
#ifndef SHARED_DEFS_H
#define SHARED_DEFS_H

#define SHM_NAME "/my_shm"
#define SEM_NAME "/my_sem"
#define SHM_SIZE sizeof(int)

#endif

