#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <pthread.h>


#define TARGET_CPU 1  // CPU core to pin the thread to

void* thread_func(void* arg) {
    cpu_set_t cpuset;
    pthread_t thread = pthread_self();
    // === Set affinity ===
    CPU_ZERO(&cpuset);
    CPU_SET(TARGET_CPU, &cpuset);

    if (pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset) != 0) {
        perror("pthread_setaffinity_np");
        pthread_exit(NULL);
    }

    printf("Thread affinity set to CPU %d\n", TARGET_CPU);

    // === Get and print affinity ===
    CPU_ZERO(&cpuset);
    if (pthread_getaffinity_np(thread, sizeof(cpu_set_t), &cpuset) != 0) {
        perror("pthread_getaffinity_np");
        pthread_exit(NULL);
    }

    printf("Thread is allowed to run on CPU(s): ");
    for (int i = 0; i < CPU_SETSIZE; i++) {
        if (CPU_ISSET(i, &cpuset)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    // Simulate work
    while (1) {
        sleep(1);
    }

    return NULL;
}

int main() {
    pthread_t thread;

    if (pthread_create(&thread, NULL, thread_func, NULL) != 0) {
        perror("pthread_create");
        return EXIT_FAILURE;
    }

    pthread_join(thread, NULL);
    return 0;
}

