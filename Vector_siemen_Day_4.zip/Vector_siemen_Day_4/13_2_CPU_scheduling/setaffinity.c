#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>

int main() {
    cpu_set_t mask;
    CPU_ZERO(&mask);           // Clear CPU set
    CPU_SET(0, &mask);         // Add CPU 0 to set

    if (sched_setaffinity(0, sizeof(mask), &mask) == -1) {
        perror("sched_setaffinity");
        return 1;
    }

    printf("Process %d bound to CPU 0\n", getpid());

    time_t start = time(NULL);
    long counter = 0;
    while (time(NULL) - start < 5) {
        counter++;
    }

    printf("Done. Count = %ld\n", counter);
    return 0;
}

/*
 CPU_ZERO(&mask);
 CPU_SET(0, &mask);
 CPU_SET(2, &mask);  // Allow CPU 0 and CPU 2
*/
