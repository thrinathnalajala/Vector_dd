// nice_version.c
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <time.h>

int main() {
    // Increase niceness by 10 (requires no root)
    int new_nice = nice(10);
    if (new_nice == -1 && errno != 0) {
        perror("nice");
        return 1;
    }

    printf("Process %d running with nice value: %d\n", getpid(), new_nice);

    time_t start = time(NULL);
    long counter = 0;
    while (time(NULL) - start < 10) {
        counter++;
    }

    printf("Finished. Count = %ld\n", counter);
    return 0;
}

