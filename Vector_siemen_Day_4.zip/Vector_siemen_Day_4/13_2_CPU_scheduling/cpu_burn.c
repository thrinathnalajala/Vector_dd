#include <stdio.h>
#include <unistd.h>
#include <time.h>

int main() {
    time_t start = time(NULL);
    long counter = 0;

    while (time(NULL) - start < 20) {  // Run for 10 seconds
        counter++;
    }

    printf("Process %d finished with count = %ld\n", getpid(), counter);
    return 0;
}

