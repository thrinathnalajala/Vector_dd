// chrt_version.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <errno.h>
#include <string.h>

int main() {
    struct sched_param param;
    param.sched_priority = 80;  // Priority 80 (range 1–99)

    // Set SCHED_RR policy (Round-Robin real-time)
    if (sched_setscheduler(0, SCHED_RR, &param) == -1) {
        perror("sched_setscheduler");
        fprintf(stderr, "You probably need to run this as root.\n");
        return 1;
    }

    printf("Process %d set to SCHED_RR with priority %d\n", getpid(), param.sched_priority);

    time_t start = time(NULL);
    long counter = 0;
    while (time(NULL) - start < 10) {
        counter++;
    }

    printf("Finished. Count = %ld\n", counter);
    return 0;
}

