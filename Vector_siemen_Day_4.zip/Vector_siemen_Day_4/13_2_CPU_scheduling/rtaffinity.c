#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <errno.h>
#include <string.h>

int main() {
    cpu_set_t cpuset;
    struct sched_param param;

    // ----------------------
    // Set CPU affinity to CPU 0
    // ----------------------
    CPU_ZERO(&cpuset);
    CPU_SET(0, &cpuset);

    if (sched_setaffinity(0, sizeof(cpuset), &cpuset) == -1) {
        perror("sched_setaffinity");
        return 1;
    }

    printf("✓ Bound to CPU 0\n");

    // ----------------------
    // Set real-time scheduling (SCHED_RR)
    // ----------------------
    param.sched_priority = 80;

    if (sched_setscheduler(0, SCHED_RR, &param) == -1) {
        perror("sched_setscheduler");
        fprintf(stderr, "✗ Failed to set real-time policy — run as root?\n");
        return 1;
    }

    printf("✓ Set SCHED_RR with priority %d\n", param.sched_priority);

    // ----------------------
    // Run CPU-bound task
    // ----------------------
    time_t start = time(NULL);
    long counter = 0;
    while (time(NULL) - start < 5) {
        counter++;
    }

    printf("Done. Count = %ld\n", counter);
    return 0;
}

