#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#define BUFFER_SIZE 8192

int main() {
    int sock;
    struct sockaddr_nl sa;
    char buffer[BUFFER_SIZE];

    // Create netlink socket
    sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0) {
        perror("socket");
        return -1;
    }

    memset(&sa, 0, sizeof(sa));
    sa.nl_family = AF_NETLINK;
    sa.nl_groups = RTMGRP_LINK;  // Listen for link (interface) changes

    if (bind(sock, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        perror("bind");
        close(sock);
        return -1;
    }

    printf("Listening for link changes...\n");

    while (1) {
        ssize_t len = recv(sock, buffer, sizeof(buffer), 0);
        if (len < 0) {
            perror("recv");
            continue;
        }

        struct nlmsghdr *nlh = (struct nlmsghdr *)buffer;
        for (; NLMSG_OK(nlh, len); nlh = NLMSG_NEXT(nlh, len)) {
            if (nlh->nlmsg_type == RTM_NEWLINK) {
                printf("Interface status changed (RTM_NEWLINK).\n");
            } else if (nlh->nlmsg_type == RTM_DELLINK) {
                printf("Interface deleted (RTM_DELLINK).\n");
            } else if (nlh->nlmsg_type == NLMSG_DONE) {
                break;
            } else {
                printf("Received netlink message type: %d\n", nlh->nlmsg_type);
            }
        }
    }

    close(sock);
    return 0;
}

