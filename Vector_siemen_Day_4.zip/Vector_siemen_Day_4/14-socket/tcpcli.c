#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define SRV_TCP_PORT 12000
#define MAX_MSG 100

#define SRV_IP_ADDR "127.0.0.1"
//#define SRV_IP_ADDR "192.168.0.22"
//
void errexit(char *str)
{
    puts(str);
    exit(0);
}


int main()
{
 int sockfd;
 struct sockaddr_in srvadr;
 char txmsg[MAX_MSG];
 char rxmsg[MAX_MSG];
 int n;
 if((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
  errexit("error open in socket\n");

  memset(&srvadr,sizeof(srvadr),0);

  srvadr.sin_family = AF_INET;
  srvadr.sin_addr.s_addr = inet_addr(SRV_IP_ADDR);
  srvadr.sin_port = htons(SRV_TCP_PORT);

   if(connect(sockfd,(struct sockaddr*)&srvadr,sizeof(srvadr)) < 0)
   errexit("connect error\n");
  
   while(1)
   {
     printf("Enter message to send\n");
     fgets(txmsg,MAX_MSG,stdin);
     if(txmsg[0] == '#')
       break;
     n = strlen(txmsg)+1;
     if(send(sockfd,txmsg,n,0)!=n)
     errexit("send error");
     
     n = recv(sockfd,rxmsg,MAX_MSG,0);
     if(n<0)
      errexit("recv");
      printf("Received messages:%s\n",rxmsg);
   }
   close(sockfd);
}     

    

