#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define SRV_UDP_PORT 8000
#define MAX_MSG 100

void errexit(char *str)
{
    puts(str);
    exit(0);
}

int main()
{
   int sockfd;
   struct sockaddr_in srvadr,cliadr;
   int clilen,n;
   char mesg[MAX_MSG];

   if((sockfd = socket(AF_INET,SOCK_DGRAM,0)) < 0)
	perror("socket problem");

	memset(&srvadr,sizeof(srvadr),0);
	
	srvadr.sin_family = AF_INET;
	srvadr.sin_addr.s_addr = htonl(INADDR_ANY);
	srvadr.sin_port = htons(SRV_UDP_PORT);
	if(bind(sockfd,(struct sockaddr*)&srvadr,sizeof(srvadr))< 0)
	perror("Error in binding\n");
	
	printf("server waiting for message\n");
	
	while(1)
	{
	  clilen = sizeof(cliadr);
	  n = recvfrom(sockfd,mesg,MAX_MSG,0,(struct sockaddr*)&cliadr,&clilen);
          if( n <0)
           perror("recv error\n");
	   if(sendto(sockfd,mesg,n,0,(struct sockaddr*)&cliadr,clilen) != n)
		perror("send error");
		printf("Received from client :%s\n %s\n",inet_ntoa(cliadr.sin_addr),mesg);
	}
}  

