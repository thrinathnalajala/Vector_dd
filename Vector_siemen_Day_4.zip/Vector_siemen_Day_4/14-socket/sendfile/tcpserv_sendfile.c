#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include <fcntl.h>


#define SRV_TCP_PORT 12000
#define MAX_MSG 100

void errexit(char *str)
{
    puts(str);
    exit(0);
}

int main()
{
   int sockfd,newsockfd,fd,rc;
   struct sockaddr_in srvadr,cliadr;
   int clilen,n,res;
   char mesg[MAX_MSG];
   struct stat statbuf;

   if((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	perror("socket problem");

	memset(&srvadr,sizeof(srvadr),0);
	
	srvadr.sin_family = AF_INET;
	srvadr.sin_addr.s_addr = htonl(INADDR_ANY);
	srvadr.sin_port = htons(SRV_TCP_PORT);
	if(bind(sockfd,(struct sockaddr*)&srvadr,sizeof(srvadr))< 0)
	perror("Error in binding\n");
	
        listen(sockfd,5);
	printf("server waiting for message\n");
	
	while(1)
	{
	  printf("server waiting for connection\n");
	  clilen = sizeof(cliadr);
          newsockfd = accept(sockfd,(struct sockaddr*)&cliadr,&clilen);
          if(newsockfd < 0)
          perror("accept error\n");
          printf("Connected to client:%s\n",inet_ntoa(cliadr.sin_addr));
          while(1)
          {
		n = recv(newsockfd,mesg,MAX_MSG,0);
		if( n < 0)
		perror("read error");
		
		if(n == 0)
		{
			close(newsockfd);
			break;
		}
		mesg[n] = 0;
          }
      	   printf("  Request for file: %s\n", mesg);

      	   /**********************************************/
      	   /* Open the file to retrieve                  */
      	   /**********************************************/
      	   fd = open(mesg, O_RDONLY);
           if (fd < 0)
           {
              perror("open() failed");
              close(newsockfd);
              exit(-1);
	   }
      	   fstat(fd,&statbuf);
           rc = sendfile(newsockfd,fd,0,statbuf.st_size);
            if (rc < 0)
            {
              perror("send_file() failed");
              close(fd);
              close(newsockfd);
              exit(-1);
            }

	 }
      
}
	
  

