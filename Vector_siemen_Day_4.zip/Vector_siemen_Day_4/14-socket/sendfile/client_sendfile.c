/*************************************************/
/* Client example requests file data from server */
/*************************************************/
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_PORT 12345

main (int argc, char *argv[])
{
   int    rc, sockfd;

   char   filename[256];
   char   buffer[32 * 1024];

   struct sockaddr_in6   addr;
   struct addrinfo hints, *res;

   /*************************************************/
   /* Initialize the socket address structure       */
   /*************************************************/
   memset(&addr, 0, sizeof(addr));
   addr.sin6_family = AF_INET6;
   addr.sin6_port   = htons(SERVER_PORT);

   /*************************************************/
   /* Determine the host name and IP address of the */
   /* machine the server is running on              */
   /*************************************************/
   if (argc < 2)
   {
      memcpy(&addr.sin6_addr, &in6addr_any, sizeof(in6addr_any));
   }
   else
   {
     memset(&hints, 0, sizeof(hints));
     hints.ai_family = AF_INET6;
     /* If the ai_family field has a value of AF_INET6 and AI_ALL is set, the AI_V4MAPPED flag 
      * must also be set to indicate that the caller accepts all addresses: IPv6 and IPv4-mapped IPv6 addresses. */
     hints.ai_flags = AI_V4MAPPED;
     rc = getaddrinfo(argv[1], NULL, &hints, &res);
     if (rc != 0)
     {
       printf("Host not found! (%s)\n", argv[1]);
       exit(-1);
     }
     
     memcpy(&addr.sin6_addr,
            (&((struct sockaddr_in6 *)(res->ai_addr))->sin6_addr),
            sizeof(addr.sin6_addr));
     
     freeaddrinfo(res);
   }

   /**************************************************/
   /* Check to see if the user specified a file name */
   /* on the command line                            */
   /**************************************************/
   if (argc == 3)
   {
      strcpy(filename, argv[2]);
   }
   else
   {
      printf("Enter the name of the file:\n");
      gets(filename);
   }

   /*************************************************/
   /* Create an AF_INET6 stream socket              */
   /*************************************************/
   sockfd = socket(AF_INET6, SOCK_STREAM, 0);
   if (sockfd < 0)
   {
      perror("socket() failed");
      exit(-1);
   }
   printf("Socket completed.\n");

   /*************************************************/
   /* Connect to the server                         */
   /*************************************************/
   rc = connect(sockfd,
                (struct sockaddr *)&addr,
                sizeof(struct sockaddr_in6));
   if (rc < 0)
   {
      perror("connect() failed");
      close(sockfd);
      exit(-1);
   }
   printf("Connect completed.\n");

   /*************************************************/
   /* Send the request over to the server           */
   /*************************************************/
   rc = send(sockfd, filename, strlen(filename) + 1, 0);
   if (rc < 0)
   {
      perror("send() failed");
      close(sockfd);
      exit(-1);
   }
   printf("Request for %s sent\n", filename);

   /*************************************************/
   /* Receive the file from the server              */
   /*************************************************/
   do
   {
      rc = recv(sockfd, buffer, sizeof(buffer), 0);
      if (rc < 0)
      {
         perror("recv() failed");
         close(sockfd);
         exit(-1);
      }
      else if (rc == 0)
      {
         printf("End of file\n");
         break;
      }
      printf("%d bytes received\n", rc);

   } while (rc > 0);

   /*************************************************/
   /* Close the socket                              */
   /*************************************************/
   close(sockfd);
}
