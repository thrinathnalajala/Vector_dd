#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
int main()
{
  char ptr[30];
  in_addr_t  ulong;
  printf("Enter ip address\n");
  scanf("%s",ptr);
  ulong = inet_addr(ptr);
  printf("%ld\n",ulong);
  printf("%d.%d.%d.%d\n",ulong&0xFF,(ulong&0xff00)>>8,(ulong&0xff0000)>>16,(ulong&0xff000000)>>24);
}
