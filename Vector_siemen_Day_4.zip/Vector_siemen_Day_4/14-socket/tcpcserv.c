#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<wait.h>
#define SRV_PORT 12000
#define MAX_MSG 100
static void grimrepeater(int signo)
{
  int savederrno;
  int errno;
  savederrno = errno;

  while(waitpid(-1,NULL,WNOHANG) > 0)
    continue;
 
  errno=savederrno;
}

void errexit(char *str)
{
    puts(str);
    exit(0);
}

int main()
{
   int sockfd,newsockfd;
   struct sockaddr_in srvadr,cliadr;
   int clilen,n;
   pid_t pid;
   char mesg[MAX_MSG];
   int exitstat,retval;
   signal(SIGCHLD,grimrepeater);
   if((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	    errexit("socket problem");

	memset(&srvadr,sizeof(srvadr),0);
	
	srvadr.sin_family = AF_INET;
	srvadr.sin_addr.s_addr = htonl(INADDR_ANY);
	srvadr.sin_port = htons(SRV_PORT);
	if(bind(sockfd,(struct sockaddr*)&srvadr,sizeof(srvadr))< 0)
	errexit("Error in binding\n");
	
        listen(sockfd,5);
	printf("server waiting for message\n");
	
	while(1)
	{
	  printf("server waiting for connection\n");
	  clilen = sizeof(cliadr);
          newsockfd = accept(sockfd,(struct sockaddr*)&cliadr,&clilen);
          if(newsockfd < 0)
          errexit("accept error\n");
          printf("Connected to client:%s\n",inet_ntoa(cliadr.sin_addr));
          pid = fork();
          if(pid == 0)
          {
            while(1)
            {
                n = recv(newsockfd,mesg,MAX_MSG,0);
                if( n < 0)
                  errexit("read error");
                
                if(n == 0)
                {
                  close(newsockfd);
                  break;
                }

                mesg[n] = 0;
                if(send(newsockfd,mesg,n,0) != n)
                  errexit("Send");
            }
                        exit(0);
          }
         else
         {
             close(newsockfd);
   //        retval = wait(&exitstat);
	            printf("Exit status= %d\n",WEXITSTATUS(exitstat));
             printf("Ret val, pid of child = %d\n",retval);
          }
     }

}
	
  

