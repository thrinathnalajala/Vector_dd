#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 8080
#define MAX_CLIENTS 10

int main() {
    int listen_fd, new_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addrlen = sizeof(client_addr);
    struct pollfd fds[MAX_CLIENTS];
    int nfds = 1;

    // Create socket
    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Bind
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    bind(listen_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));

    // Listen
    listen(listen_fd, 5);

    // Setup initial pollfd
    fds[0].fd = listen_fd;
    fds[0].events = POLLIN; // Ready to accept

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        int poll_count = poll(fds, nfds, -1); // Wait indefinitely
        if (poll_count < 0) {
            perror("poll");
            break;
        }

        // Check for new connections
        if (fds[0].revents & POLLIN) {
            new_fd = accept(listen_fd, (struct sockaddr *)&client_addr, &addrlen);
            if (new_fd >= 0) {
                printf("New connection from %s:%d\n",
                    inet_ntoa(client_addr.sin_addr),
                    ntohs(client_addr.sin_port));

                if (nfds < MAX_CLIENTS) {
                    fds[nfds].fd = new_fd;
                    fds[nfds].events = POLLIN;
                    nfds++;
                } else {
                    printf("Too many clients.\n");
                    close(new_fd);
                }
            }
        }

        // Check for data on client sockets
        for (int i = 1; i < nfds; ++i) {
            if (fds[i].revents & POLLIN) {
                char buffer[1024] = {0};
                int bytes = read(fds[i].fd, buffer, sizeof(buffer));
                if (bytes <= 0) {
                    printf("Client disconnected (fd %d)\n", fds[i].fd);
                    close(fds[i].fd);
                    fds[i] = fds[nfds - 1]; // Remove client
                    nfds--;
                    i--; // Check this slot again
                } else {
                    printf("Received: %s\n", buffer);
                    send(fds[i].fd, buffer, bytes, 0); // Echo back
                }
            }
        }
    }

    close(listen_fd);
    return 0;
}

