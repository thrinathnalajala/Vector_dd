// poll_example.c
#include <stdio.h>
#include <poll.h>
#include <unistd.h>

int main() {
    struct pollfd pfd[2];
    int ret;

    pfd[0].fd = STDIN_FILENO; // stdin
    pfd[0].events = POLLIN;
    pfd[1].fd = STDOUT_FILENO; // stdout
    pfd[1].events = POLLOUT;

    printf("Waiting for input (poll)...\n");

    ret = poll(&pfd, 2, 5000); // 5000ms = 5s
    if (ret == -1) {
        perror("poll");
    } else if (ret == 0) {
        printf("Timeout!\n");
    } else {
        if (pfd[0].revents & POLLIN)
            printf("Data is available on stdin!\n");
        if (pfd[1].revents & POLLOUT)
            printf("Data is available on stdout!\n");
    }

    return 0;
}

