#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define SRV_UDP_PORT 8000
#define MAX_MSG 100

//#define SRV_IP_ADDR "192.168.0.22"
#define SRV_IP_ADDR "127.0.0.1"
void errexit(char *str)
{
    puts(str);
    exit(0);
}

int main()
{
 int sockfd;
 struct sockaddr_in srvadr;
 char txmsg[MAX_MSG];
 char rxmsg[MAX_MSG];
 int n;
 if((sockfd = socket(AF_INET,SOCK_DGRAM,0)) < 0)
  perror("error open in socket\n");

 memset(&srvadr,sizeof(srvadr),0);

 srvadr.sin_family = AF_INET;
 srvadr.sin_addr.s_addr = inet_addr(SRV_IP_ADDR);
 srvadr.sin_port = htons(SRV_UDP_PORT);
 printf("Enter message to send\n");
 fgets(txmsg,MAX_MSG,stdin);
 n=strlen(txmsg)+1;
 if(sendto(sockfd,txmsg,n,0,(struct sockaddr*)&srvadr,sizeof(srvadr)) != n)
    errexit("send error\n");
 n = recv(sockfd,rxmsg,MAX_MSG,0);
 if(n < 0)
   errexit("Error receiving\n");
 printf("Received message:%s\n",rxmsg);
}

