#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = 0;  // Let the OS pick the port

    bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

    struct sockaddr_in localaddr;
    socklen_t len = sizeof(localaddr);
    getsockname(sockfd, (struct sockaddr*)&localaddr, &len);

    printf("Local IP: %s\n", inet_ntoa(localaddr.sin_addr));
    printf("Local port: %d\n", ntohs(localaddr.sin_port));

    return 0;
}

