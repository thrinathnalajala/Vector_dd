#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include <stdio.h>
#define MAX_MSG 100
#define SRV_UDP_PORT 8000
void errExit(char *str)
{
  puts(str);
  exit(0);
}
int main()
{
  struct timeval tv;
  int sockFd,stat;
  struct sockaddr_in srvAdr, cliAdr;
  int cliLen,n;
  char mesg[MAX_MSG];
  fd_set readfds, testfds;
  if( (sockFd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    errExit("Can't open datagram socket\n");
  memset(&srvAdr,0,sizeof(srvAdr));
  srvAdr.sin_family = AF_INET;
  srvAdr.sin_addr.s_addr = htonl(INADDR_ANY);
  srvAdr.sin_port = htons(SRV_UDP_PORT);
  if(bind(sockFd,(struct sockaddr*)&srvAdr, sizeof(srvAdr)) < 0)
   errExit("Can't bind local address\n");
  printf("Server waiting for messages\n");
  FD_ZERO(&readfds);
  FD_SET(sockFd,&readfds);
  while(1)
  {
     testfds = readfds;
     tv.tv_sec = 5;
     tv.tv_usec = 0;
     stat= select(sockFd+1, &testfds, (fd_set *)0, (fd_set *)0, &tv);
     if(stat == 0)
     {
	//printf("Time out error\n");
	continue;
     }
     cliLen = sizeof(cliAdr);
     n = recvfrom(sockFd, mesg, MAX_MSG, 0,(struct sockaddr*)&cliAdr, &cliLen);
     if(sendto(sockFd,mesg,n,0,(struct sockaddr*)&cliAdr,cliLen) != n)
	errExit("sendto error\n");
     printf("Received following message from client %s\n%s\n",inet_ntoa(cliAdr.sin_addr),mesg);
  }
}
