// select_example.c
#include <stdio.h>
#include <sys/select.h>
#include <unistd.h>

int main() {
    fd_set readfds;
    struct timeval timeout;
    int ret;

    FD_ZERO(&readfds);
    FD_SET(STDIN_FILENO, &readfds); // stdin (fd 0)

    timeout.tv_sec = 5;
    timeout.tv_usec = 0;

    printf("Waiting for input (select)...\n");

    ret = select(STDIN_FILENO + 1, &readfds, NULL, NULL, &timeout);
    if (ret == -1) {
        perror("select");
    } else if (ret == 0) {
        printf("Timeout!\n");
    } else {
	    if((ret > 0) && (FD_ISSET(STDIN_FILENO, &readfds)))
            {
	       char buffer[100];
	       ret = read(STDIN_FILENO, buffer, sizeof(buffer));
               printf("Data is available on stdin!:%s", buffer);

	    }
    }

    return 0;
}

