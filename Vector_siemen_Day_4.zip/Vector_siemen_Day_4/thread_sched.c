#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sched.h>
#include <unistd.h> // Required for sleep()

// Function to be executed by the thread
void *thread_function(void *arg) {
    int thread_num = *(int *)arg;
    struct sched_param param;
    int policy;
    pthread_getschedparam(pthread_self(), &policy, &param);
    printf("Thread %d: Initial policy: %d, priority: %d\n", thread_num, policy, param.sched_priority);
    
    // Simulate some work
    for (int i = 0; i < 5; ++i) {
        printf("Thread %d: Working... (iteration %d)\n", thread_num, i);
        sleep(1);
    }

    pthread_getschedparam(pthread_self(), &policy, &param);
    printf("Thread %d: Final policy: %d, priority: %d\n", thread_num, policy, param.sched_priority);

    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2;
    pthread_attr_t attr;
    struct sched_param param;
    int rc;
    int thread_num1 = 1, thread_num2 = 2;

    // Initialize thread attributes
    pthread_attr_init(&attr);

    // Set thread 1 to SCHED_FIFO with priority 10 (requires root or CAP_SYS_NICE)
    pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    param.sched_priority = 10;
    pthread_attr_setschedparam(&attr, &param);
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED); // Explicitly inherit

    rc = pthread_create(&thread1, &attr, thread_function, &thread_num1);
    if (rc) {
        fprintf(stderr, "Error: pthread_create failed for thread1, error code: %d\n", rc);
        return 1;
    }

    // Set thread 2 to SCHED_RR with priority 5 (requires root or CAP_SYS_NICE)
    pthread_attr_setschedpolicy(&attr, SCHED_RR);
    param.sched_priority = 5;
    pthread_attr_setschedparam(&attr, &param);
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);

    rc = pthread_create(&thread2, &attr, thread_function, &thread_num2);
    if (rc) {
        fprintf(stderr, "Error: pthread_create failed for thread2, error code: %d\n", rc);
        return 1;
    }

    // Join the threads
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Cleanup
    pthread_attr_destroy(&attr);

    return 0;
}
