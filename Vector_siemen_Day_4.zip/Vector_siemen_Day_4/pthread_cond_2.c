#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int buffer = 0;
int available = 0; // 0 = empty, 1 = full

void* producer(void* arg) {
    for (int i = 1; i <= 5; ++i) {
        pthread_mutex_lock(&lock);
        
        while (available == 1) {
            pthread_cond_wait(&cond, &lock); // wait for buffer to be empty
        }

        buffer = i;
        printf("Produced: %d\n", buffer);
        available = 1;

        pthread_cond_signal(&cond); // signal consumer
        pthread_mutex_unlock(&lock);

        sleep(1); // simulate time to produce
    }
    return NULL;
}

void* consumer(void* arg) {
    for (int i = 1; i <= 5; ++i) {
        pthread_mutex_lock(&lock);

        while (available == 0) {
            pthread_cond_wait(&cond, &lock); // wait for buffer to be full
        }

        printf("Consumed: %d\n", buffer);
        available = 0;

        pthread_cond_signal(&cond); // signal producer
        pthread_mutex_unlock(&lock);

        sleep(2); // simulate time to consume
    }
    return NULL;
}

int main() {
    pthread_t prod, cons;

    pthread_create(&cons, NULL, consumer, NULL);
    pthread_create(&prod, NULL, producer, NULL);

    pthread_join(prod, NULL);
    pthread_join(cons, NULL);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cond);

    return 0;
}

