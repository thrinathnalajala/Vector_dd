#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>

#define QUEUE_NAME  "/loop_server_queue"
#define MAX_SIZE    1024

int main() {
    mqd_t mq;
    char message[MAX_SIZE];

    // Open the queue
    mq = mq_open(QUEUE_NAME, O_WRONLY);
    if (mq == -1) {
        perror("Client: mq_open");
        exit(EXIT_FAILURE);
    }

    printf("Client started. Type messages to send. Type 'exit' to stop the server.\n");

    while (1) {
        printf("Enter message: ");
        if (fgets(message, MAX_SIZE, stdin) == NULL) {
            break;
        }

        // Remove trailing newline
        message[strcspn(message, "\n")] = '\0';

        if (mq_send(mq, message, strlen(message), 0) == -1) {
            perror("Client: mq_send");
            break;
        }

        if (strcmp(message, "exit") == 0) {
            printf("[Client] Exit command sent. Exiting.\n");
            break;
        }
    }

    mq_close(mq);
    return 0;
}

