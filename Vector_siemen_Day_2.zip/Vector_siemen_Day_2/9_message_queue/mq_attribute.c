#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>       // For O_* constants
#include <sys/stat.h>    // For mode constants
#include <mqueue.h>
#include <errno.h>

#define QUEUE_NAME "/attr_test_queue"
#define MAX_SIZE   1024

int main() {
    mqd_t mq;
    struct mq_attr attr, old_attr;
    char buffer[MAX_SIZE];

    // Define initial attributes
    attr.mq_flags = 0;              // Blocking mode
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MAX_SIZE;
    attr.mq_curmsgs = 0;

    // Create message queue
    mq = mq_open(QUEUE_NAME, O_CREAT | O_RDWR, 0644, &attr);
    if (mq == -1) {
        perror("mq_open");
        exit(EXIT_FAILURE);
    }

    printf("Queue created successfully.\n");

    // Get and display current attributes
    if (mq_getattr(mq, &attr) == -1) {
        perror("mq_getattr");
        exit(EXIT_FAILURE);
    }

    printf("Initial queue attributes:\n");
    printf("  mq_flags   = %ld\n", attr.mq_flags);
    printf("  mq_maxmsg  = %ld\n", attr.mq_maxmsg);
    printf("  mq_msgsize = %ld\n", attr.mq_msgsize);
    printf("  mq_curmsgs = %ld\n", attr.mq_curmsgs);

    // Set non-blocking mode
    struct mq_attr new_attr;
    new_attr.mq_flags = O_NONBLOCK;

    if (mq_setattr(mq, &new_attr, &old_attr) == -1) {
        perror("mq_setattr");
        exit(EXIT_FAILURE);
    }

    printf("\nChanged mq_flags to O_NONBLOCK. Previous flags: %ld\n", old_attr.mq_flags);

    // Try to receive from empty queue (should fail immediately due to non-blocking mode)
    if (mq_receive(mq, buffer, MAX_SIZE, NULL) == -1) {
        if (errno == EAGAIN) {
            printf("mq_receive (non-blocking): No message available (EAGAIN).\n");
        } else {
            printf("mq_receive");
        }
    }

    mq_close(mq);
    mq_unlink(QUEUE_NAME);
    return 0;
}

