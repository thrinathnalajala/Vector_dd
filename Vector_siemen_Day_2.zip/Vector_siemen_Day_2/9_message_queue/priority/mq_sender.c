#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>

#define QUEUE_NAME  "/priority_queue"
#define MAX_SIZE    1024

int main() {
    mqd_t mq;
    struct mq_attr attr;
    char message[MAX_SIZE];

    // Set queue attributes
    attr.mq_flags = 0;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MAX_SIZE;
    attr.mq_curmsgs = 0;

    // Create the queue
    mq = mq_open(QUEUE_NAME, O_CREAT | O_WRONLY, 0644, &attr);
    if (mq == -1) {
        perror("Sender: mq_open");
        exit(EXIT_FAILURE);
    }

    // Send messages with different priorities
    snprintf(message, MAX_SIZE, "Low priority message");
    mq_send(mq, message, strlen(message) + 1, 1);

    snprintf(message, MAX_SIZE, "Medium priority message");
    mq_send(mq, message, strlen(message) + 1, 5);

    snprintf(message, MAX_SIZE, "High priority message");
    mq_send(mq, message, strlen(message) + 1, 10);

    printf("Messages sent with priorities 1, 5, and 10.\n");

    mq_close(mq);
    //mq_unlink(QUEUE_NAME);
    return 0;
}

