#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>

#define QUEUE_NAME  "/priority_queue"
#define MAX_SIZE    1024

int main() {
    mqd_t mq;
    char buffer[MAX_SIZE];
    unsigned int prio;

    // Open the queue
    mq = mq_open(QUEUE_NAME, O_RDONLY);
    if (mq == -1) {
        perror("Receiver: mq_open");
        exit(EXIT_FAILURE);
    }

    printf("Receiver started. Waiting for messages...\n");

    for (int i = 0; i < 3; ++i) {
        ssize_t bytes_read = mq_receive(mq, buffer, MAX_SIZE, &prio);
        if (bytes_read >= 0) {
            buffer[bytes_read] = '\0';  // Null terminate the string
            printf("[Receiver] Received (priority %u): %s\n", prio, buffer);
        } else {
            perror("mq_receive");
        }
    }

    mq_close(mq);
    mq_unlink(QUEUE_NAME);
    return 0;
}

