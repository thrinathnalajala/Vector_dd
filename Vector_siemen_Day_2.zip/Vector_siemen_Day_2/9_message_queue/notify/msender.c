#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define MQ_NAME "/test_queue"
#define MAX_SIZE 1024

int main() {
    mqd_t mq;
    char message[MAX_SIZE];

    // Open the queue for writing
    mq = mq_open(MQ_NAME,  O_CREAT | O_WRONLY,0644, NULL);
    if (mq == (mqd_t)-1) {
        perror("mq_open");
        exit(EXIT_FAILURE);
    }

    // Send multiple messages
    for (int i = 0; i < 5; ++i) {
        snprintf(message, MAX_SIZE, "Message %d", i + 1);
        if (mq_send(mq, message, strlen(message) + 1, 0) == -1) {
            perror("mq_send");
        } else {
            printf("Sent: %s\n", message);
        }
        sleep(1);  // Slow down sends for demo purposes
    }

    mq_close(mq);
    return 0;
}

