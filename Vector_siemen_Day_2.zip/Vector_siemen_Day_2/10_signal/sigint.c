#include<signal.h>

void siginthandler(int signo)
{
  printf("Signal Hanlder\n");
}

int main()
{
  signal(SIGINT,siginthandler);
  while(1)
  {
  }
}

