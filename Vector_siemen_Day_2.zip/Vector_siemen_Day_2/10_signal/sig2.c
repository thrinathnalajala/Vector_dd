#include<signal.h>
int sigint,sigusr1,sigusr2,sigalrm,sgother;

void siginthandler(int signo)
{
  printf("Signal Hanlder\n");
}

void generichandler(int signo)
{
  printf("generic Signal Hanlder\n");
  switch(signo)
  {
    case SIGUSR1:
  printf("user1Signal Hanlder\n");
          sigusr1++;
          break;

    case SIGUSR2:
  printf(" user2 Signal Hanlder\n");
          sigusr2++;
          break;
    default:
	sgother++;
  }
}

void sigalarmhandler(int signo)
{
   alarm(5);
   sigalrm++;
}

int main()
{
  signal(SIGINT,siginthandler);
  signal(SIGUSR1,generichandler);
  signal(SIGUSR2,generichandler);
  signal(SIGALRM,sigalarmhandler);

  alarm(5);
  while(1)
  {
     //suspends execution of the process until the call is interrupted by a signal handler
     pause(); 
     printf("%d %d %d %d %d\n",sigint,sigusr1,sigusr2,sigalrm,sgother);
  }
}

