#include <stdio.h>
#include <signal.h>

void handler(int sig) {
    printf("Caught signal %d\n", sig);
}

int main() {
    signal(SIGUSR1, handler);  // Set custom handler
    raise(SIGUSR1);            // Raise signal
    return 0;
}

