#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void print_pending_signals() {
    sigset_t pending;
    if (sigpending(&pending) == -1) {
        perror("sigpending");
        exit(EXIT_FAILURE);
    }

    printf("Pending signals: ");
    for (int sig = 1; sig < NSIG; sig++) {
        if (sigismember(&pending, sig)) {
            printf("%d ", sig);
        }
    }
    printf("\n");
}

int main() {
    sigset_t blockSet;

    // Block SIGINT and SIGTERM
    sigemptyset(&blockSet);
    sigaddset(&blockSet, SIGINT);
    sigaddset(&blockSet, SIGTERM);

    if (sigprocmask(SIG_BLOCK, &blockSet, NULL) == -1) {
        perror("sigprocmask");
        exit(EXIT_FAILURE);
    }

    printf("SIGINT and SIGTERM are now blocked.\n");
    printf("Send SIGINT or SIGTERM (Ctrl+C or kill) now. Sleeping for 10 seconds...\n");
    sleep(10);

    print_pending_signals();

    // Unblock signals to allow delivery
    sigprocmask(SIG_UNBLOCK, &blockSet, NULL);

    printf("Signals unblocked, exiting.\n");
    while(1);
    return 0;
}

