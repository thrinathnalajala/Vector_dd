#include <signal.h>
#include <unistd.h>

void handler(int sig) {
    const char msg[] = "Signal received\n";
    write(STDOUT_FILENO, msg, sizeof(msg) - 1);  // async-signal-safe
}

int main() {
    signal(SIGINT, handler);
    while(1) pause();
}

