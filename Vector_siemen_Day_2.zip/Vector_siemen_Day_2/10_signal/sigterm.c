#include <signal.h>
#include <stdio.h>
#include <unistd.h>

void handle_sigterm(int sig) {
    printf("Received SIGTERM. Cleaning up...\n");
    // Do cleanup here
    _exit(0);
}

int main() {
    signal(SIGTERM, handle_sigterm);
    printf("Running... PID=%d\n", getpid());
    while (1) pause();
}

