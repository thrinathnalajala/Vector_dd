#include <signal.h>
#include <unistd.h>

int main() {
    pid_t pgid = getpgrp();  // get current process group
    killpg(pgid, SIGTERM);   // terminate all in this group
    return 0;
}

