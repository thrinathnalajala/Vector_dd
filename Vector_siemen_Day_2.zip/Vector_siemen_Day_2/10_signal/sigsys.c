#include <unistd.h>
#include<signal.h>

void mysighandler()
{
  printf("Bad signal number\n");
  //close(sock)
  //close(fd)
  //close(sfd)
  exit(0);
}
int main() {
    signal(SIGSYS,mysighandler);
    syscall(0xFFFF); // invalid syscall number
//    int *p=NULL;
 //   *p=9;
    return 0;
}

