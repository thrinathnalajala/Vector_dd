#include<signal.h>
void mysighandler()
{
  printf("I am in singal Handler\n");
  //close(sock)
  //close(fd)
  //close(sfd)
  exit(0);
}

int main()
{
  signal(SIGINT,mysighandler);
//  char *p=0x20000;
 // *p=30;
  while(1)
  {
    sleep(15);
  }
}
