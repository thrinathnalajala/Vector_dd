#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define SIG_EVENT (SIGRTMIN)

void signal_handler(int sig, siginfo_t *si, void *ucontext) {
    printf("[Handler] Signal %d received.\n", sig);
    printf("[Handler] Received value: %d\n", si->si_value.sival_int);
}

int main() {
    struct sigaction sa;
    timer_t timerid;
    struct sigevent sev;
    struct itimerspec its;
    union sigval sv;

    // Set up signal handler with SA_SIGINFO
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = signal_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIG_EVENT, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    // Configure the timer to send a signal
    sev.sigev_notify = SIGEV_SIGNAL;
    sev.sigev_signo = SIG_EVENT;
    sev.sigev_value.sival_int = 42; // Payload

    if (timer_create(CLOCK_REALTIME, &sev, &timerid) == -1) {
        perror("timer_create");
        exit(EXIT_FAILURE);
    }

    // Set timer to fire once after 2 seconds
    its.it_value.tv_sec = 2;
    its.it_value.tv_nsec = 0;
    its.it_interval.tv_sec = 0;
    its.it_interval.tv_nsec = 0;

    if (timer_settime(timerid, 0, &its, NULL) == -1) {
        perror("timer_settime");
        exit(EXIT_FAILURE);
    }

    printf("Timer set. Waiting for signal...\n");

    // Main thread can do other work here
    while (1) {
        pause(); // Wait for signal
    }

    return 0;
}

