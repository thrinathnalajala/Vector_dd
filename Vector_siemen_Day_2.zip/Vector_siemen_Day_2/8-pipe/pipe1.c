#include<stdio.h>
int main()
{
  int fds[2],i,n;
  char readbuf[100];
  char writebuf[100];
  
  if(pipe(fds)<0)
  {
    printf("pipe error\n");
  }
  if(fork()==0)
  {
   close(fds[1]);
   while(1)
   {
    n=read(fds[0],readbuf,100);
    for(i=0;i<n;i++)
    readbuf[i]=toupper(readbuf[i]);
    printf("%s",readbuf);
   }
  }
  close(fds[0]);
  while(1)
  {
    fgets(writebuf,50,stdin);
    //scanf("%s",writebuf);
    write(fds[1],writebuf,strlen(writebuf)+1);
  }
}
