#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#define BUF_LEN 256
void togglecase(char *buf,int len);
int main()
{
  int srvfd,clifd;
  char buf[BUF_LEN];
  int cnt;
  while(1)
  {
     printf("Waiting for connecting to client\n");
     srvfd=open("srvfifo",O_RDONLY);
     if(srvfd < 0)
     {
        if(mkfifo("srvfifo",0600)<0)
        {
           printf("Error in creating FIFO\n");
           return(1);
        }
        else
        {
           srvfd=open("srvfifo",O_RDONLY);
        }       
    }
    printf("Connected to client through FIFO\n");

    while(1)
    {
       cnt=read(srvfd,buf,BUF_LEN);
       if(cnt==0)
          break;
       printf("Received mesage:%s\n",buf);
       togglecase(buf,cnt);
       clifd=open("clififo",O_WRONLY);
       if(clifd)
       {
          printf("Send response message:%s\n",buf);
          write(clifd,buf,cnt);
          close(clifd);
       }
       else
       {
          printf("Not able to open\n");
       }
   }
   close(srvfd);
  }
}
void togglecase(char *buf,int cnt)
{
  int ii;
  for(ii=0;ii<cnt;ii++)
  {
     if((buf[ii] >='A') && (buf[ii] <='Z'))
        buf[ii] += 0X20;
     else if ((buf[ii] >='a') && (buf[ii] <='z'))
       buf[ii] -= 0x20;
   }
} 
