#include<stdio.h>
int main()
{
  int fds1[2],i,n,fds2[2];
  char readbuf[100];
  char writebuf[100];
  
  if(pipe(fds1)<0)
  {
    printf("pipe error\n");
  }

  if(pipe(fds2)<0)
  {
    printf("pipe error\n");
  }
  if(fork()==0)
  {
   close(fds2[0]);
   close(fds1[1]);
   while(1)
   {
    n=read(fds1[0],readbuf,100);
    printf("Read from server %s",readbuf);
    for(i=0;i<n;i++)
    readbuf[i]=toupper(readbuf[i]);
    write(fds2[1],readbuf,strlen(readbuf)+1);
    //printf("%s",readbuf);
   }
  }
  close(fds1[0]);
 close(fds2[1]);
  while(1)
  {
    fgets(writebuf,50,stdin);
    //scanf("%s",writebuf);
    write(fds1[1],writebuf,strlen(writebuf)+1);
    n=read(fds2[0],readbuf,100);
    printf("Read from client %s",readbuf);
  }
}
