#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#define BUF_LEN 256
void togglecase(char *buf,int len);
int main()
{
   int srvfd,clifd;
   char txbuf[BUF_LEN];
   char rxbuf[BUF_LEN];
   int cnt;
   srvfd=open("srvfifo",O_WRONLY);
   if(srvfd < 0)
   {
      printf("Erro writing to server\n");
   }
   printf("Connected to Server through FIFO\n");
   printf("Enter some text...");

   fgets(txbuf,BUF_LEN,stdin);
   write(srvfd,txbuf,strlen(txbuf)+1);
   clifd=open("clififo",O_RDONLY);
   if(clifd < 0)
   {
   if(mkfifo("clififo",0600)<0)
   {
      printf("Error in creating FIFO\n");
      return(1);
   }
   else
   {
      clifd=open("clififo",O_RDONLY);
   }
}
printf("Receiving mesage...\n");
cnt=read(clifd,rxbuf,BUF_LEN);
puts(rxbuf);
close(srvfd);
close(clifd);
}
