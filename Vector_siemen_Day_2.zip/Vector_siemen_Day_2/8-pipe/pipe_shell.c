#include<stdio.h>
int main()
{
  int pfds[2];
  

  if(pipe(pfds)<0)
  {
    printf("Error in pipe creation\n");
    exit(0);
  }
  switch(fork())
  {
    case -1:
    		printf("Error in process creation\n");
                break;
    case 0:
		if(close(pfds[0])== -1)
                printf("Error in pipe close \n");
                if(pfds[1]!=stdout)
		{
		 if(dup2(pfds[1],1)== -1)
 		 {
		   printf("Error in dupe process creation\n");
                   exit(1);
                 }
                }
                if(close(pfds[1])== -1)
                printf("Error in pipe close \n");
                execlp("ls", "ls", (char *) NULL); 
                break;
    default:
		break;
   }

  switch(fork())
  {
    case -1:
                printf("Error in process creation\n");
                break;
    case 0:
                if(close(pfds[1])== -1)
                printf("Error in pipe close \n");
                if(pfds[0]!=stdin)
                {
                 if(dup2(pfds[0],0)== -1)
                 {
                   printf("Error in dupe process creation\n");
                   exit(1);
                 }
                }
                if(close(pfds[0])== -1)
                printf("Error in pipe close \n");
                execlp("wc", "wc","-l", (char *) NULL);
                break;
    default:
                break;
   }        	        

if (close(pfds[0]) == -1)
//errExit("close 5");
                printf("Error in pipe close \n");
if (close(pfds[1]) == -1)
//errExit("close 6");
                printf("Error in pipe close \n");
if (wait(NULL) == -1)
//errExit("wait 1");
                printf("Error in wait\n");
if (wait(NULL) == -1)
//errExit("wait 2");
                printf("Error in wait\n");
}
