#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#define MY_KEY 19920809
#define SHM_SIZE 0x1000
void togglecase(char *buf,int len);
int main()
{
  int semid,shmid;
  char *pshm;
  struct sembuf sb;
  semid = semget(MY_KEY,2,0660 | IPC_CREAT);
  if(semid < 0)
  {
    perror("sem operation failed\n");
    exit(1);
  }
  printf("Sem id =%d",semid);

  semctl(semid,0,SETVAL,0);
  semctl(semid,1,SETVAL,0);
  shmid = shmget(MY_KEY,SHM_SIZE,0660 | IPC_CREAT);
  if(shmid < 0)
  {
    perror("shm operation failed\n");
    exit(2);
  }

  pshm = shmat(shmid, NULL,0);
  printf("Sem address =%x",pshm);
  if(!pshm)
  {
    perror("Could not attached shared memory segment\n");
    exit(3);
  }
  
  while(1)
  {
    sb.sem_num = 0;
    sb.sem_op = -1;
    sb.sem_flg = 0;
    semop(semid,&sb,1);
    printf("Got semaphore\n");
    strcpy(pshm+256,pshm);
    togglecase(pshm+256,strlen(pshm+256));
    sb.sem_num = 1;
    sb.sem_op = 1;
    sb.sem_flg = 0;
    semop(semid,&sb,1);
  }
}

void togglecase(char *buf,int cnt)
{
  int ii;
  for(ii=0;ii<cnt;ii++)
  {
     if((buf[ii] >='A') && (buf[ii] <='Z'))
     buf[ii] += 0X20;
     else if ((buf[ii] >='a') && (buf[ii] <='z'))
     buf[ii] -= 0x20;
  }
}


