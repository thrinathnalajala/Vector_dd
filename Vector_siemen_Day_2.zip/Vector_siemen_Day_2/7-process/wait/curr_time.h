/* curr_time.h

   Header file for curr_time.c.
*/
#ifndef CURR_TIME_H
#define CURR_TIME_H             /* Prevent accidental double inclusion */

char *currTime(const char *fmt);

#endif
