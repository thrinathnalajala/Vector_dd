int main()
{
  printf("I am in process, my process id :%d\n",getpid());
  printf("I am in process, my parent process id :%d\n",getppid());
  printf("I am in process, creating child process\n");
  fork();
  printf("my id  %d and my parent pid %d\n",getpid(),getppid());
  getchar();
}
