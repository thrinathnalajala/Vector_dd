int main()
{
  unsigned int pid,stat;
  printf("I am in process, my process id :%d\n",getpid());
  printf("I am in process, my parent process id :%d\n",getppid());
  printf("I am in process, creating child process\n");
  pid = fork();

  if(pid)
    {
	
	//wait(&stat);
	getchar();
	printf("parent process:%d\n",pid);
     }
  else
    {
	printf("child process\n");
	getchar();
	getchar();
	getchar();
    }
           
}
