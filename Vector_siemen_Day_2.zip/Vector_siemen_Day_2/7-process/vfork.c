/*************************************************************************\
*                  Copyright (C) Michael Kerrisk, 2022.                   *
*                                                                         *
* This program is free software. You may use, modify, and redistribute it *
* under the terms of the GNU General Public License as published by the   *
* Free Software Foundation, either version 3 or (at your option) any      *
* later version. This program is distributed without any warranty.  See   *
* the file COPYING.gpl-v3 for details.                                    *
\*************************************************************************/

/* t_vfork.c

   Demonstrate the use of vfork() to create a child process.
*/

int main(int argc, char *argv[])
{
    int istack = 222;

    switch (vfork()) {
    case -1:
        perror("vfork");

    case 0:             /* Child executes first, in parent's memory space */
        sleep(3);                   /* Even if we sleep for a while,
                                       parent still is not scheduled */
        write(1, "Child executing\n", 16);
        istack *= 3;                /* This change will be seen by parent */
        exit(0);

    default:            /* Parent is blocked until child exits */
        write(1, "Parent executing\n", 17);
        printf("istack=%d\n", istack);
        exit(0);
    }
}
