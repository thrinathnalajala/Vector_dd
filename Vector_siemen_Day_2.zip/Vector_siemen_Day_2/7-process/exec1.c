int main()
{
  char *args[2];
  printf(" I am going to exec an ls program\n");
  execl("/bin/ls","ls",0);
  printf("I executed ls\n");
  execl("/bin/ls","ls",0);
}
