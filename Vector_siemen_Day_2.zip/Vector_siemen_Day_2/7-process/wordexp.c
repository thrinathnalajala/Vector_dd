#include <wordexp.h>
#include <stdio.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <dlfcn.h>

//int (*main)(int argc, char **argv);

int main()
{
    char *input;
    wordexp_t args;
    int i, ret;
    char **w;

    while (1) {
        input = readline("cmd> ");
        if ((ret = wordexp(input, &args, 0)) != 0) {
            fprintf(stderr, "error: %d\n", ret);
            continue;
        }
        w = args.we_wordv;
        for (i = 0; i < args.we_wordc; i++)
           printf("%s\n", w[i]);

       wordfree(&args);
    }

    return 0;
}
