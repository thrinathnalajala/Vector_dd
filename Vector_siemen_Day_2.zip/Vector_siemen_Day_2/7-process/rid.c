#include <stdio.h>
#include <unistd.h>

int main() {
    uid_t ruid, euid, suid;

    if (getresuid(&ruid, &euid, &suid) == 0) {
        printf("Real UID: %d\n", ruid);
        printf("Effective UID: %d\n", euid);
        printf("Saved UID: %d\n", suid);
    } else {
        perror("getresuid");
    }

    return 0;
}

