#define NIC_PATH "/tmp/log"
#define NIC_LIST ("ifconfig -a >" NIC_PATH )
int main()
{
  system("ls -lrt");
  printf("ls completed\n");
  system(NIC_LIST);
}
