int main()
{
  printf("I am in process, my process id :%d\n",getpid());
  printf("I am in process, my parent process id :%d\n",getppid());
  while(1);
}
