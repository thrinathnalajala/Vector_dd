#include<stdio.h>
static int stat_init = 5;
static int stat_uninit;
int global_init = 10;
int global_uninit;
void display()
{
    static int a=10;
}
static void drone()
{
    static int a=10;
}
int main()
{
    char ch1,ch2,ch3;
    char *p = "rama";
    char ch[] = "abc";
    ch1 = 65;
    ch2 = 'b';
    ch3 = '3';
    printf("Ch1=%c\n",ch1);
    printf("Ch2=%c\n",ch2);
    printf("Ch3=%c\n",ch3);
    printf("Ch1=%x\n",ch1);
    printf("Ch2=%x\n",ch2);
    printf("Ch3=%x\n",ch3);
}
