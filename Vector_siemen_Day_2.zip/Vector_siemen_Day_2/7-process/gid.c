#include <unistd.h>
#include <stdio.h>

int main() {
    printf("Real UID: %d\n", getuid());
    printf("Real Group ID: %d\n", getgid());
    printf("Effective UID: %d\n", geteuid());
    printf("Effective Group UID: %d\n", getegid());
    return 0;
}

