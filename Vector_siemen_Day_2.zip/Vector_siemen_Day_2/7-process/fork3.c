#include<sys/types.h>
#include<sys/wait.h>
int main()
{
 pid_t chpid,child1,child2;
 int ii,stat;
 printf(" i am in my process id %d\n",getpid());
 child1=fork();
 if(child1==0)
 {
  printf("iam first child:%d\n",getpid());
  for(ii=0;ii<6;ii++)
  {
    printf(" aim in for loop\n");
    sleep(10);
  }
  return(2);
 }
 child2=fork();
 if(child2==0)
 {
  printf("iam second child:%d\n",getpid());
  for(ii=0;ii<8;ii++)
  {
    printf(" aim in for loop\n");
    sleep(5);
  }
  exit(3);
 }
chpid=wait(&stat);
 if(chpid==child1)
 printf("My first child is terminated:%d\n",WEXITSTATUS(stat));

 if(chpid==child2)
 printf("My second child is terminated:%d\n",WEXITSTATUS(stat));


 chpid=wait(&stat);
 if(chpid==child1)
 printf("My first child is terminated:%d\n",WEXITSTATUS(stat));

 if(chpid==child2)
 printf("My second child is terminated:%d\n",WEXITSTATUS(stat));
}
