#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<fcntl.h>
int main()
{
 pid_t chpid,child1,child2;
 int ii,stat,fd;
 char  buffer;
 fd = open("abc.txt",O_RDONLY|O_WRONLY);
 child1=fork();
 if(child1)
 {
   chpid=wait(&stat);
   read(fd,&buffer,1);
   printf("%c\n",buffer);
   printf("pid of parent:%u\n",getpid());
 }
 else
 {
   buffer = 'p';
   write(fd,&buffer,1);
   read(fd,&buffer,1);
   printf("%c\n",buffer);
   printf("pid of child:%u\n",getpid());
 }
}
