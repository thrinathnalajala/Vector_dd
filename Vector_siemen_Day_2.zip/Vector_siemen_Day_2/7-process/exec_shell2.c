#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
int main()
{
 pid_t pid;
 int option,stat;
 char cmdbuf[80];
 char *charmsg[4];
 while(1)
 {
   printf("myshell>");
   gets(cmdbuf);
   charmsg[0]=cmdbuf;
   charmsg[1]=0;
   if(strncmp(cmdbuf,"ver",3)==0)
   {
     printf("Simple shell version\n");
     continue;
   }

   if(strncmp(cmdbuf,"quit",4)==0)
   exit(0);
   
   if(fork()==0)
   {
     execvp(cmdbuf,charmsg);
     //execvp("/bin/ls","-lrt");
     exit(0);
   }
   pid=wait(&stat);
}
}
